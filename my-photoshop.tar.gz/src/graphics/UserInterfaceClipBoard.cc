#include "UserInterface.hh"

QClipboard* UserInterface::getClipBoard(){
    return m_clipboard;
}

