#include "AlgebricOperationChooser.hh"



/** Constructeurs et destructeur */
AlgebricOperationChooser::AlgebricOperationChooser() {
  setAccessibleName(QString("AlgebricOp"));
}

AlgebricOperationChooser::~AlgebricOperationChooser() {}
