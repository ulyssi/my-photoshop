#ifndef _ALGEBRIC_OPERATION_CHOOSER_HH_
#define _ALGEBRIC_OPERATION_CHOOSER_HH_

#include <QLabel>
#include <QString>


class AlgebricOperationChooser : public QLabel { Q_OBJECT

public:

  /** Constructeurs et destructeur */
  AlgebricOperationChooser();
  ~AlgebricOperationChooser();

};

#endif
