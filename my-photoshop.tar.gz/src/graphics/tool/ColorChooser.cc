#include "ColorChooser.hh"

#include <QString>


ColorChooser::ColorChooser() {
  setAccessibleName(QString("Color"));
}

ColorChooser::~ColorChooser() {}
