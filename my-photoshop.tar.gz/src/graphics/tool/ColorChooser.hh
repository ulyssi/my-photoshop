#ifndef _COLOR_CHOOSER_HH_
#define _COLOR_CHOOSER_HH_

#include <QLabel>


class ColorChooser : public QLabel { Q_OBJECT

public:

  /** Constructeurs et destructeur */
  ColorChooser();
  ~ColorChooser();

};

#endif
